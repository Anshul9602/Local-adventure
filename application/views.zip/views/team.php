<script src="
https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js
"></script>
<link href="
https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css
" rel="stylesheet">
<style>
  .mainb {
    background-image: url(assets/img/ab.jpg);
    background-position: 50% 235%;
    background-size: cover;
    height: 50vh;
  }

  .section-title-w {
    padding-bottom: 40px;
    margin-top: 30vh;
  }

  .section-title-w h2 {
    color: #f1f1f1;
    font-size: 14px;
    font-weight: 500;
    padding: 0;
    margin: 0 0 5px 0;
    letter-spacing: 2px;
    text-transform: uppercase;
  }

  .section-title-w p {
    color: #fff;
    font-size: 36px;
    font-weight: 700;
    text-transform: uppercase;
    font-family: "Poppins", sans-serif;
  }
</style>


<!-- ======= Hero Section ======= -->
<section class="d-flex flex-column justify-content-end align-items-center mainb">

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="section-title-w">
          <h2>Team</h2>
          <p>Our Company</p>
        </div>
      </div>
    </div>
  </div>

</section><!-- End Hero -->

<main id="main">

 <!-- ======= Team Section ======= -->
 <section id="team" class="team">
      <div class="container">

        <div class="section-title" data-aos="zoom-out">
          <h2>Team</h2>
          <p>Our Hardworking Team</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up">
              <div class="member-img">
                <img src="assets/img/team/team-1.jpg" class="img-fluid" alt="">
                <div class="social d-none">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Hardik Ghori</h4>
                <span>Chief Executive Officer</span>
              </div>
            </div>
          </div>

          

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="200">
              <div class="member-img">
                <img src="assets/img/team/team-3.jpg" class="img-fluid" alt="">
                
              </div>
              <div class="member-info">
                <h4>William Anderson</h4>
                <span>CTO</span>
              </div>
            </div>
          </div>

        
        </div>

      </div>
    </section><!-- End Team Section -->

  <!-- ======= Cta Section ======= -->
  <section id="cta" class="cta">
    <div class="container">

      <div class="row" data-aos="zoom-out">
        <div class="col-lg-9 text-center text-lg-start">
          <h3>Call To Action</h3>
          <p> Never miss out on our latest news and exclusive offers.</p>
        </div>
        <div class="col-lg-3 cta-btn-container text-center">
          <a class="cta-btn align-middle" href="#">Subscribe</a>
        </div>
      </div>

    </div>
  </section><!-- End Cta Section -->
 

  <section id="about" class="about">
    <div class="container">

      <div class="section-title" data-aos="zoom-out">
        <h2>Our Certifications</h2>

      </div>

      <div class="row content" data-aos="fade-up">
        <div class="col-md-12 pt-4 pt-lg-0">
          <img src="assets/img/cl/cr1.PNG" width="100%" alt="">
        </div>
        
        

      </div>

    </div>
  </section><!-- End About Section -->

</main><!-- End #main -->
<script>
  var splide = new Splide('.splide', {
    perPage: 8,
    perMove: 2,
    gap: 20, 
    rewind: true,
    autoplay: true, // Enable auto-sliding
    breakpoints: {
      768: {
        perPage: 2, // Change perPage to 2 on screens >= 768px
      },
      576: {
        perPage: 1, // Change perPage to 1 on screens >= 576px
      }
    }
  });

  splide.mount();

</script>